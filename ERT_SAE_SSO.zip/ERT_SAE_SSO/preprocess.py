import os
import pickle

import numpy as np
from sklearn.preprocessing import StandardScaler

DATA_DIR = "Data/data"
DATA_SAVE_DIR = "Data/preprocessed"
os.makedirs(DATA_SAVE_DIR, exist_ok=True)


def scale(train_x, test_x, ss=None, inverse=False):
    print("[INFO] Preprocessing Data Using StandardScaler")
    if ss is None:
        ss = StandardScaler()
        ss.fit(np.concatenate([train_x, test_x], axis=0))
        return ss.transform(train_x), ss.transform(test_x), ss
    else:
        if inverse:
            return ss.inverse_transform(train_x), ss.inverse_transform(test_x)
        else:
            return ss.transform(train_x), ss.transform(test_x)


def preprocess(data, inverse=False):
    ss_path = os.path.join(DATA_SAVE_DIR, "ss.pkl")
    if inverse:
        with open(ss_path, "rb") as f:
            ss = pickle.load(f)
            train_x, test_x, ss = scale(
                data["train_x"], data["test_x"], ss=ss, inverse=True
            )
    else:
        if not os.path.isfile(ss_path):
            train_x, test_x, ss = scale(data["train_x"], data["test_x"])
            with open(ss_path, "wb") as f:
                pickle.dump(ss, f)
        else:
            with open(ss_path, "rb") as f:
                ss = pickle.load(f)
                train_x, test_x = scale(
                    data["train_x"], data["test_x"], ss=ss, inverse=True
                )
    return train_x, test_x


def preprocess_data():
    dp = os.path.join(DATA_DIR, "data.npz")
    print("[INFO] Loading Prepared Data :: {0}".format(dp))
    data = np.load(dp)
    train_y, test_y = data["train_y"], data["test_y"]
    train_x, test_x = preprocess(data)
    train_x = np.array(train_x)
    train_y = np.array(train_y)
    test_x = np.array(test_x)
    test_y = np.array(test_y)
    sp = os.path.join(DATA_SAVE_DIR, "data.npz")
    print("[INFO] Saving Preprocessed Data :: {0}".format(sp))
    np.savez(sp, train_x=train_x, train_y=train_y, test_x=test_x, test_y=test_y)


if __name__ == "__main__":
    preprocess_data()
