if True:
    from reset_random import reset_random

    reset_random()
from tensorflow.python.keras.layers import Input, Dense
from tensorflow.python.keras.models import Sequential, Model
from models.SSO import ShuffleSpheredOptimizer
from models.HHO import HarrisHawksOptimizer

IN_DIM = 208
HIDDEN_DIM = 512
ENCODER_DIM = 768
OUT_DIM = 812


OPTIMIZERS = {
    'HHO': HarrisHawksOptimizer,
    'SSO': ShuffleSpheredOptimizer
}


def build_encoder():
    print("[INFO] Building Encoder Model")
    model = Sequential(name="encoder")
    model.add(Dense(HIDDEN_DIM, activation="relu", input_dim=IN_DIM))
    model.add(Dense(ENCODER_DIM, activation="relu"))
    return model


def build_decoder():
    print("[INFO] Building Decoder Model")
    model = Sequential(name="decoder")
    model.add(Dense(HIDDEN_DIM, activation="relu", input_dim=ENCODER_DIM))
    model.add(Dense(OUT_DIM, activation="sigmoid"))
    return model


def build_autoencoder(opt):
    encoder = build_encoder()
    decoder = build_decoder()

    print("[INFO] Building AutoEncoder")
    input_ = Input(shape=(IN_DIM,))
    latent_vector = encoder(input_)
    output_ = decoder(latent_vector)
    model = Model(input_, output_)
    print("[INFO] Compiling Model Using {0}".format(OPTIMIZERS[opt].__name__))
    model.compile(optimizer=OPTIMIZERS[opt](), loss="mse")
    return encoder, decoder, model
