import os

import matplotlib
import numpy as np
import pandas as pd
from matplotlib import pyplot as plt
from matplotlib import style
from tensorflow.python.keras.callbacks import Callback

from data_visualize import draw_2d

style.use('seaborn-v0_8-darkgrid')
matplotlib.use('Qt5Agg')
plt.rcParams['font.family'] = 'JetBrains Mono'

COORD = pd.read_csv('Data/data/MESH.csv').values


class TrainingCallbackDSAE(Callback):
    def __init__(self, loss_path, train_x, train_y, test_x, test_y):
        self.loss_path = loss_path
        self.pred_dir = os.path.join(os.path.dirname(self.loss_path), 'predicted')
        os.makedirs(self.pred_dir, exist_ok=True)
        self.train_x = train_x
        self.train_y = train_y
        self.test_x = test_x
        self.test_y = test_y
        if os.path.isfile(self.loss_path):
            self.df = pd.read_csv(self.loss_path)
            self.plot()
        else:
            self.df = pd.DataFrame([], columns=['epoch', 'loss', 'val_loss'])
            self.df.to_csv(self.loss_path, index=False)
        Callback.__init__(self)

    def plot(self):
        y1 = self.df['loss'].values.ravel()
        y2 = self.df['val_loss'].values.ravel()
        plot_line(y1, y2, len(self.df), 'Loss', self.loss_path.replace('.csv', '.png'))

    def on_epoch_end(self, epoch, logs=None):
        self.df.loc[len(self.df.index)] = [
            int(epoch + 1), round(logs['loss'], 4), round(logs['val_loss'], 4),
        ]
        self.df.to_csv(self.loss_path, index=False)
        # print('\t[AUTOENCODER => (Epoch :: {0})] -> Loss :: {1} | Val_Loss :: {2}'.format(
        #     epoch + 1, *[format(v, '.4f') for v in self.df.values[-1][1:]]
        # ))
        self.plot()

        train_pred = self.model.predict(self.train_x[:4])
        test_pred = self.model.predict(self.test_x[:4])
        fig = plot_prediction(self.train_y[3], self.test_y[3], train_pred[3], test_pred[3])
        fig.suptitle('Actual Vs Reconstructed on Epoch :: {0}'.format(epoch + 1))
        fig.savefig(os.path.join(self.pred_dir, 'Epoch_{0}.png'.format(epoch + 1)))


def plot_prediction(train_y, test_y, train_pred, test_pred):
    fig = plt.figure(num=2, figsize=(12.8, 8.6))
    fig.clear()

    combined_data = (np.concatenate((train_y, test_y), axis=0))
    _min, _max = np.amin(combined_data), np.amax(combined_data)

    ax1 = fig.add_subplot(2, 2, 1)
    draw_2d(ax1, COORD, train_y, _min, _max, 'Train Actual')

    ax2 = fig.add_subplot(2, 2, 2)
    draw_2d(ax2, COORD, train_pred, _min, _max, 'Train Reconstructed')

    ax3 = fig.add_subplot(2, 2, 3)
    draw_2d(ax3, COORD, test_y, _min, _max, 'Test Actual')

    ax4 = fig.add_subplot(2, 2, 4)
    draw_2d(ax4, COORD, test_pred, _min, _max, 'Test Reconstructed')

    return fig


def plot_line(y1, y2, epochs, for_, save_path):
    fig = plt.figure(num=1)
    ax = fig.gca()
    ax.clear()
    ax.plot(range(epochs), y1, label='Training', color='dodgerblue')
    ax.plot(range(epochs), y2, label='Validation', color='orange')
    ax.set_title('Training and Validation {0}'.format(for_))
    ax.set_xlabel('Epochs')
    ax.set_ylabel(for_)
    ax.set_xlim([0, epochs])
    ax.legend()
    fig.tight_layout()
    fig.savefig(save_path)
