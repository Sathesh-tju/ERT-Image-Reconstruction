if True:
    from reset_random import reset_random

    reset_random()
import os
import numpy as np
import pandas as pd
import tqdm
from scipy.io import loadmat

GROUPS = list(range(1, 11))
DATA_DIR = 'Data/source'
DATA_SAVE_DIR = 'Data/data'
os.makedirs(DATA_SAVE_DIR, exist_ok=True)


def load_mesh_data():
    MESH_DATA_PATH = os.path.join(DATA_DIR, 'data_Sen_Mesh.mat')
    print('[INFO] Loading Mesh Data :: {0}'.format(MESH_DATA_PATH))
    mesh_data = loadmat(MESH_DATA_PATH)

    keys = ['Sensitivity', 'mesh', 'idx_num', 'mesh_sq']
    for k in keys:
        sp = os.path.join(DATA_SAVE_DIR, '{0}.csv'.format(k))
        print('[INFO] {0} Shape :: {1}'.format(k, mesh_data[k].shape))
        print('[INFO] Saving {0} :: {1}'.format(k, sp))
        pd.DataFrame(mesh_data[k]).to_csv(sp, index=False)


def load_group(group):
    data_dir = os.path.join(DATA_DIR, 'Group{0}'.format(group))
    train_x = loadmat(os.path.join(data_dir, 'traineu.mat'))['traineu']
    train_y = loadmat(os.path.join(data_dir, 'trainec.mat'))['trainec']
    test_x = loadmat(os.path.join(data_dir, 'testeu.mat'))['testeu']
    test_y = loadmat(os.path.join(data_dir, 'testec.mat'))['testec']
    train_x, test_x = x[:37011], x[37011:]
    train_y, test_y = y[:37011], y[37011:]
    return train_x, train_y, test_x, test_y


def prepare_data():
    train_x, train_y, test_x, test_y = [], [], [], []
    for group in tqdm.tqdm(GROUPS, desc='[INFO] Loading Group :'):
        trx, try_, tex, tey = load_group(group)
        train_x.extend(trx)
        train_y.extend(try_)
        test_x.extend(tex)
        test_y.extend(tey)
    train_x = np.array(train_x)
    train_y = np.array(train_y)
    test_x = np.array(test_x)
    test_y = np.array(test_y)
    print('[INFO] Train X Shape :: {0}'.format(train_x.shape))
    print('[INFO] Train Y Shape :: {0}'.format(train_y.shape))
    print('[INFO] Test X Shape :: {0}'.format(test_x.shape))
    print('[INFO] Test Y Shape :: {0}'.format(test_y.shape))
    sp = os.path.join(DATA_SAVE_DIR, 'data.npz')
    print('[INFO] Saving Data :: {0}'.format(sp))
    np.savez(sp, train_x=train_x, train_y=train_y, test_x=test_x, test_y=test_y)


if __name__ == '__main__':
    load_mesh_data()
    prepare_data()
