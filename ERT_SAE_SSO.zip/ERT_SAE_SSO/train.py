if True:
    from reset_random import reset_random

    reset_random()
import os
import sys
import numpy as np
import pandas as pd
from tensorflow.python.keras.callbacks import ModelCheckpoint
from models.SAE import build_autoencoder, OPTIMIZERS
from training_utils import TrainingCallbackDSAE


def train(opt, train_x, train_y, test_x, test_y):
    model_dir = "trained_model/{0}".format(opt)
    os.makedirs(model_dir, exist_ok=True)

    loss_csv_path = os.path.join(model_dir, "loss.csv")
    model_path = os.path.join(model_dir, "autoencoder.h5")
    training_cb = TrainingCallbackDSAE(loss_csv_path, train_x, train_y, test_x, test_y)
    checkpoint = ModelCheckpoint(
        model_path,
        save_best_only=True,
        save_weights_only=True,
        monitor="val_loss",
        mode="min",
        verbose=False,
    )

    encoder, decoder, autoencoder = build_autoencoder(opt)

    initial_epoch = 0
    if os.path.isfile(model_path) and os.path.isfile(loss_csv_path):
        print("[INFO] Loading Pre-Trained Model :: {0}".format(model_path))
        autoencoder.load_weights(model_path)
        initial_epoch = len(pd.read_csv(loss_csv_path))

    print("[INFO] Fitting Data")
    autoencoder.fit(
        train_x,
        train_y,
        validation_data=(test_x, test_y),
        epochs=100,
        verbose=1,
        batch_size=128,
        initial_epoch=initial_epoch,
        callbacks=[training_cb, checkpoint],
    )
    encoder.save_weights(os.path.join(model_dir, "encoder.h5"))
    decoder.save_weights(os.path.join(model_dir, "decoder.h5"))


if __name__ == "__main__":
    argv = sys.argv
    if len(argv) == 1:
        print("[ERROR] Optimizer Name Must Be Passed!")
    else:
        opt = argv[1]
        if opt not in OPTIMIZERS:
            print(
                "[ERROR] Optimizer Name Must Be in {0}".format(list(OPTIMIZERS.keys()))
            )
        else:
            dp = "Data/preprocessed/data.npz"
            print("[INFO] Loading Data From :: {0}".format(dp))
            data = np.load(dp)
            trx, try_, tex, tey = (
                data["train_x"],
                data["train_y"],
                data["test_x"],
                data["test_y"],
            )
            print("[INFO] Train X Shape :: {0}".format(trx.shape))
            print("[INFO] Train Y Shape :: {0}".format(try_.shape))
            print("[INFO] Test X Shape :: {0}".format(tex.shape))
            print("[INFO] Test Y Shape :: {0}".format(tey.shape))
            train(opt, trx, try_, tex, tey)
