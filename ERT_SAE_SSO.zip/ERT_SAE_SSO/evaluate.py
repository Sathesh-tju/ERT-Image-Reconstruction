if True:
    from reset_random import reset_random

    reset_random()
import os.path

import matplotlib
import numpy as np
import pandas as pd
from matplotlib import pyplot as plt
from matplotlib import style

from models.SAE import build_autoencoder
from prepare_data import GROUPS

style.use("seaborn-v0_8-darkgrid")
matplotlib.use("Qt5Agg")
plt.rcParams["font.family"] = "JetBrains Mono"


MEASURES = {
    "MIN_RIE": "Min-RelativeImageError",
    "MAX_RIE": "Max-RelativeImageError",
    "AVG_RIE": "Avg-RelativeImageError",
    "MIN_ICC": "Min-ImageCorrelationCoefficient",
    "MAX_ICC": "Max-ImageCorrelationCoefficient",
    "AVG_ICC": "Avg-ImageCorrelationCoefficient",
    "MSE": "Mean square error",
    "SSIM": "Structural Similarity Index Measure",
}


def get_measures(y_true, y_pred):
    rie_abs = np.abs(y_true - y_pred)
    min_rie = np.min(rie_abs, axis=1)
    max_rie = np.max(rie_abs, axis=1)
    avg_rie = np.mean(rie_abs, axis=1)

    err_mean1 = y_true - np.mean(y_true)
    err_mean2 = y_pred - np.mean(y_pred)
    nume = err_mean1 * err_mean2
    denom = np.sqrt(np.sum(err_mean1**2) * np.sum(err_mean2**2))
    _ = nume / denom
    icc_abs = 1 - ((y_true - y_pred) ** 2)
    min_icc = np.min(icc_abs, axis=1)
    max_icc = np.max(icc_abs, axis=1)
    avg_icc = np.mean(icc_abs, axis=1)
    MSE = np.mean((y_true - y_pred) ** 2, axis=1)
    mean_x = np.mean(y_true, axis=1)
    mean_y = np.mean(y_pred, axis=1)
    var_x = np.sum(err_mean1**2, axis=1) / (y_true.shape[0] - 1)
    var_y = np.sum(err_mean2**2, axis=1) / (y_pred.shape[0] - 1)
    covar_xy = np.sum(nume, axis=1) / (y_true.shape[0] - 1)
    c1 = 0.01**2
    c2 = 0.03**2
    ssim = (((2 * mean_x * mean_y) + c1) * (covar_xy**c2)) / (
        (mean_x + mean_y + c1) * (var_x + var_y + c2)
    )
    return np.concatenate(
        [
            min_rie.reshape(-1, 1),
            max_rie.reshape(-1, 1),
            avg_rie.reshape(-1, 1),
            min_icc.reshape(-1, 1),
            max_icc.reshape(-1, 1),
            avg_icc.reshape(-1, 1),
            MSE.reshape(-1, 1),
            ssim.reshape(-1, 1),
        ],
        axis=1,
    ), [
        min_rie.mean(),
        max_rie.mean(),
        avg_rie.mean(),
        min_icc.mean(),
        max_icc.mean(),
        avg_icc.mean(),
        MSE.mean(),
        ssim.mean(),
    ]


def plot(rd, train_m, test_m):
    for i, m in enumerate(MEASURES):
        y1 = train_m[:, i][:100]
        y2 = test_m[:, i][:100]
        x = range(1, len(y1) + 1)
        fig = plt.figure(num=1)
        ax = fig.gca()
        ax.clear()
        ax.plot(x, y1, label="Train", color="dodgerblue")
        ax.plot(x, y2, label="Test", color="orange")
        ax.set_title("100 Samples of Train and Test")
        ax.set_xlabel(MEASURES[m])
        ax.set_ylabel("Values")
        ax.legend()
        fig.tight_layout()
        fig.savefig(os.path.join(rd, "{0}.png".format(m)))


def evaluate(group, autoencoder, opt, train_x, train_y, test_x, test_y):
    results_dir = "results/{0}/Group{1}".format(opt, group)
    os.makedirs(results_dir, exist_ok=True)

    print("\t\t[INFO] Predicting Train Data")
    train_pred = autoencoder.predict(train_x)
    print("\t\t[INFO] Evaluating Train Data")
    train_m, train_mo = get_measures(train_y, train_pred)

    print("\t\t[INFO] Predicting Test Data")
    test_pred = autoencoder.predict(test_x)
    print("\t\t[INFO] Evaluating Test Data")
    test_m, test_mo = get_measures(test_y, test_pred)
    print("\t\t[INFO] Plotting Test Measures")
    plot(results_dir, train_m, test_m)

    return train_pred, test_pred, train_m, train_mo, test_m, test_mo


def plot_bar(dat, title, x_label, y_label, x_labels, legend_list, save_path, lim):
    rect_list = []

    def width_adjust(a_width):
        optimized_width = a_width * len(dat[0])

        count = len(str(a_width)) - 2
        adjustment = "0."
        while count > 0:
            adjustment += "0"
            count -= 1
        adjustment += "1"
        adjustment = float(adjustment)
        while optimized_width + gap * len(dat[0]) >= 0.95:
            a_width -= adjustment
            optimized_width = a_width * len(dat[0])
        return a_width

    def group_chart():
        cmap = plt.get_cmap("tab10")
        for i in range(len(dat)):
            x = -((len(dat[0]) - 1) * (width + gap) / 2) + i
            for j in range(len(dat[0])):
                rect_list.append(ax.bar(x, dat[i][j], width, color=cmap.colors[j]))
                # ax.text(x - 0.2, dat[i][j] + 0.0001, str(round(dat[i][j], 4)))
                x += width + gap

    def legend():
        rect_li = [rec[0] for rec in rect_list]
        ax.legend(rect_li, legend_list, bbox_to_anchor=(1.0, 1.0))

    ind = np.arange(len(dat))
    width = 0.5
    gap = 0.0

    fig = plt.figure(figsize=(8.6, 4.8))
    ax = fig.gca()
    width = width_adjust(width)
    group_chart()

    ax.set_xlabel(x_label, labelpad=10)
    ax.set_ylabel(y_label, labelpad=10)
    ax.set_xticks(ind)
    ax.set_xticklabels(x_labels)
    # ax.set_ylim(*lim)
    legend()
    ax.set_title(title, pad=12)
    fig.tight_layout()
    fig.savefig(save_path)


def plot_overall(df1, df2, for_):
    print("[INFO] Plotting Overall Measures")
    lims = {
        "MIN_RIE": [-0.5, 1.5],
        "MAX_RIE": [0.7, 0.95],
        "AVG_RIE": [0.012, 0.021],
        "MIN_ICC": [0.2, 0.5],
        "MAX_ICC": [0.9, 1.1],
        "AVG_ICC": [0.9, 1.1],
        "MSE": [0.001, 0.006],
        "SSIM": [0.001, 0.006],
    }
    sd = os.path.join("results", for_)
    os.makedirs(sd, exist_ok=True)
    for m in MEASURES:
        df_data = [df1[m].values.tolist(), df2[m].values.tolist()]
        dat = np.array(df_data).T
        plot_bar(
            dat=dat,
            title="{0}ing Data Comparison On\nDifferent Groups and Optimizers".format(
                for_
            ),
            x_label="Groups",
            y_label=MEASURES[m],
            x_labels=GROUPS,
            legend_list=["HHO", "SSO"],
            save_path="{0}/{1}.png".format(sd, m),
            lim=lims[m],
        )


if __name__ == "__main__":
    dp = "Data/preprocessed/data.npz"
    print("[INFO] Loading Data From :: {0}".format(dp))
    data = np.load(dp)
    trx, try_, tex, tey = (
        data["train_x"],
        data["train_y"],
        data["test_x"],
        data["test_y"],
    )
    print("[INFO] Train X Shape :: {0}".format(trx.shape))
    print("[INFO] Train Y Shape :: {0}".format(try_.shape))
    print("[INFO] Test X Shape :: {0}".format(tex.shape))
    print("[INFO] Test Y Shape :: {0}".format(tey.shape))
    for opt in ["HHO", "SSO"]:
        trs = trx.shape[0] // 10
        tes = tex.shape[0] // 10
        trp, tep, trm, trmo, tem, temo = [], [], [], [], [], []
        model_path = "trained_model/{0}/autoencoder.h5".format(opt)
        _, _, autoencoder = build_autoencoder(opt)
        print("[INFO] Loading Pre-Trained Model Weights :: {0}".format(model_path))
        autoencoder.load_weights(model_path)
        DATA_SAVE_DIR = "Data/eval/{0}".format(opt)
        os.makedirs(DATA_SAVE_DIR, exist_ok=True)
        for grp, trs_s, tes_s in zip(
            GROUPS, range(0, trx.shape[0], trs), range(0, tex.shape[0], tes)
        ):
            print("\t[INFO] Working on Group :: {0}".format(grp))
            eval_data = evaluate(
                grp,
                autoencoder,
                opt,
                trx[trs_s : trs_s + trs],
                try_[trs_s : trs_s + trs],
                tex[tes_s : tes_s + tes],
                tey[tes_s : tes_s + tes],
            )
            trp.append(eval_data[0])
            tep.append(eval_data[1])
            trm.append(eval_data[2])
            trmo.append(eval_data[3])
            tem.append(eval_data[4])
            temo.append(eval_data[5])
        trp = np.array(trp)
        tep = np.array(tep)
        trm = np.array(trm)
        trmo = np.array(trmo)
        tem = np.array(tem)
        temo = np.array(temo)
        sp = os.path.join(DATA_SAVE_DIR, "data.npz")
        print("\t[INFO] Saving Evaluated Data :: {0}".format(sp))
        np.savez(
            sp,
            train_pred=trp,
            test_pred=tep,
            train_m=trm,
            train_mo=trmo,
            test_m=tem,
            test_mo=temo,
        )
        print("\t[INFO] Saving Overall Measures")
        df = pd.DataFrame(trmo, columns=list(MEASURES.keys()))
        df.insert(0, "Group", GROUPS)
        df.to_csv(
            os.path.join("results/{0}".format(opt), "train_measures.csv"), index=False
        )
        df = pd.DataFrame(temo, columns=list(MEASURES.keys()))
        df.insert(0, "Group", GROUPS)
        df.to_csv(
            os.path.join("results/{0}".format(opt), "test_measures.csv"), index=False
        )
    plot_overall(
        pd.read_csv("results/HHO/train_measures.csv"),
        pd.read_csv("results/SSO/train_measures.csv"),
        "Train",
    )
    plot_overall(
        pd.read_csv("results/HHO/test_measures.csv"),
        pd.read_csv("results/SSO/test_measures.csv"),
        "Test",
    )
