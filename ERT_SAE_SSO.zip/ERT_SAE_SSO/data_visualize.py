import numpy as np
from matplotlib import pyplot as plt

plt.rcParams['font.family'] = 'JetBrains Mono'


def draw_mesh(ax, coord):
    ax.triplot(coord[:, 0], coord[:, 1])
    ax.axis('equal')
    return ax


def draw_2d(ax, coord, y, _min, _max, title):
    ax.clear()
    ax.tripcolor(coord[:, 0], coord[:, 1], y, shading='flat', vmin=_min, vmax=_max, 
                 cmap=plt.get_cmap('jet'))
    ax.autoscale(False)
    ax.axis('equal')
    ax.set_title(title)
    return ax


def plot_data(coord, y1, y2, show=False):
    combined_data = (np.concatenate((y1, y2), axis=0))
    _min, _max = np.amin(combined_data), np.amax(combined_data)

    fig = plt.figure(num=1)
    ax1 = fig.add_subplot(1, 2, 1)
    ax2 = fig.add_subplot(1, 2, 2)
    draw_2d(ax1, coord, y1, _min, _max, 'Actual')
    draw_2d(ax2, coord, y2, _min, _max, 'Predicted')

    if show:
        plt.show()
    return fig
