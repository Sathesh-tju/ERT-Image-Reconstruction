import os
import numpy as np
from scipy.io import loadmat

from models.SAE import build_autoencoder

_, _, model = build_autoencoder('SSO')
if os.path.isfile('trained_model/SSO/autoencoder.h5'):
    model.load_weights('trained_model/SSO/autoencoder.h5')

def get_data(path):
    dat = loadmat(path)
    keys = [k for k in dat.keys() if not k.startswith('__')]
    x, y = [], []
    for k in keys:
        x.append(dat[k][0][0][0].ravel())
        y.append(dat[k][0][0][1].ravel())
    x = np.array(x)
    y = np.array(y)
    return x, y, keys


def predict_all(x):
    pred = model.predict(x)
    return pred


if __name__ == '__main__':
    get_data('test_data/econd.mat')
