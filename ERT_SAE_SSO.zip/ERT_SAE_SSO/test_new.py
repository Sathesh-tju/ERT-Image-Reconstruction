if True:
    from reset_random import reset_random

    reset_random()
import os
import pickle
import sys

import numpy as np
from PyQt5.QtCore import Qt
from PyQt5.QtGui import QFont
from PyQt5.QtWidgets import QApplication, QGridLayout
from PyQt5.QtWidgets import QHBoxLayout, QLabel, QSizePolicy, QSlider, QSpacerItem, \
    QVBoxLayout, QWidget, QPushButton, QFileDialog, QMessageBox
from matplotlib import pyplot as plt
from matplotlib.backends.backend_qt import NavigationToolbar2QT
from matplotlib.backends.backend_qtagg import FigureCanvasQTAgg
from data_visualize import draw_2d
from evaluate import get_measures
from test_new_mat import get_data, predict_all
from training_utils import COORD


class Slider(QWidget):
    def __init__(self, parent=None):
        super(Slider, self).__init__(parent=parent)
        self.horiLayout = QHBoxLayout(self)
        self.label = QLabel("Sample::{0:.4g}".format(0))
        self.horiLayout.addWidget(self.label)
        self.verticalLayout = QVBoxLayout()
        spacerItem = QSpacerItem(20, 0, QSizePolicy.Expanding, QSizePolicy.Minimum)
        self.verticalLayout.addItem(spacerItem)
        self.slider = QSlider(self)
        self.slider.setMinimum(0)
        self.slider.setMaximum(0)
        self.slider.setOrientation(Qt.Horizontal)
        self.verticalLayout.addWidget(self.slider)
        self.horiLayout.addLayout(self.verticalLayout)
        self.resize(self.sizeHint())


class FigureCanvas(QWidget):
    def __init__(self, fig):
        super(QWidget, self).__init__()

        self.lt = QVBoxLayout()
        self.fig = fig
        self.fc = FigureCanvasQTAgg(fig)
        self.lt.addWidget(self.fc)
        self.tb = NavigationToolbar2QT(self.fc, self)
        self.lt.addWidget(self.tb)
        self.setLayout(self.lt)


class ERT(QWidget):
    def __init__(self):
        super(ERT, self).__init__()

        self.setWindowTitle(' ')
        self.setWindowFlags(Qt.WindowCloseButtonHint | Qt.WindowMinimizeButtonHint)
        self.setWindowState(Qt.WindowMaximized)

        self.app_width = QApplication.desktop().availableGeometry().width() // 100
        self.app_height = QApplication.desktop().availableGeometry().height() // 100

        self.main_layout = QGridLayout()
        self.main_layout.setSpacing(25)
        self.main_layout.setAlignment(Qt.AlignCenter | Qt.AlignTop)

        self.title_lb = QLabel('Electrical Resistance Tomography Reconstruction'.upper())
        self.title_lb.setFont(QFont('JetBrains Mono', 24))
        self.main_layout.addWidget(self.title_lb, 0, 0, Qt.AlignCenter)

        self.btn_layout = QGridLayout()
        self.main_layout.addLayout(self.btn_layout, 1, 0, Qt.AlignCenter)

        self.choose_btn = QPushButton('Choose MAT File')
        self.choose_btn.clicked.connect(self.choose_input)
        self.btn_layout.addWidget(self.choose_btn, 0, 0)

        self.slider = Slider()
        self.slider.setFixedWidth(self.app_width * 95)
        self.main_layout.addWidget(self.slider, 2, 0, Qt.AlignCenter)

        self.fig, (self.ax1, self.ax2) = plt.subplots(1, 2, num=1)
        self.fig_c = FigureCanvas(self.fig)
        self.fig_c.setFixedSize(self.app_width * 95, self.app_height * 75)
        self.main_layout.addWidget(self.fig_c, 3, 0, Qt.AlignCenter)

        self.x_data = []
        self.y_data = []
        self.pred_data = []
        self.c_data = []
        self.setLayout(self.main_layout)

        self.showMaximized()

    def choose_input(self):
        filter_ = "MAT Files (*.mat)"
        self._input_image_path, _ = QFileDialog.getOpenFileName(
            self,
            caption="Choose Input Data",
            directory="test_data",
            options=QFileDialog.DontUseNativeDialog,
            filter=filter_
        )
        if os.path.isfile(self._input_image_path):
            self.choose_btn.setEnabled(False)
            x, y, keys = get_data(self._input_image_path)
            with open('Data/preprocessed/ss.pkl', 'rb') as f:
                ss = pickle.load(f)
                x = ss.transform(x)
            pred = predict_all(x)
            self.x_data = x.copy()
            self.y_data = y.copy()
            self.pred_data = pred
            self.c_data = [self.y_data, self.pred_data, get_measures(self.y_data, self.pred_data)]
            self.slider.slider.valueChanged.connect(self.update_slice)
            self.update_data()
        else:
            self.show_message_box('InputImageError', QMessageBox.Critical, 'Choose valid image?')

    def update_data(self):
        self.slider.slider.setMinimum(0)
        self.slider.slider.setMaximum(self.y_data.shape[0])
        self.slider.slider.setValue(0)
        self.update_slice()

    def update_slice(self):
        value = self.slider.slider.value() - 1
        self.slider.label.setText("Sample {0} / {1}".format(value + 1, self.y_data.shape[0]))
        combined_data = np.concatenate([self.c_data[0][value], self.c_data[0][value]], axis=0)
        _min, _max = np.amin(combined_data), np.amax(combined_data)
        draw_2d(self.ax1, COORD, self.c_data[0][value], _min, _max,
                'Actual Min={0:.4f} Max={1:.4f}'.format(
                    np.min(self.c_data[0][value]),
                    np.max(self.c_data[0][value])
                ))
        draw_2d(self.ax2, COORD, self.c_data[1][value], _min, _max,
                'Predicted Min={0:.4f} Max={1:.4f}'.format(
                    np.min(self.c_data[1][value]),
                    np.max(self.c_data[1][value])
                ))
        self.fig.suptitle(
            '2D Reconstruction\n'
            'RIE(MIN={0:.4f}, MAX={1:.6f}, AVG={2:.6f})\nICC(MIN={3:.6f}, MAX={4:.6f}, AVG={5:.6f})\nMSE={6:.6f} | SSIM={7:.6f}'.format(
                *self.c_data[2][0][value]
            )
        )
        self.fig.tight_layout()
        self.fig_c.fc.draw()
        self.fig_c.fc.flush_events()


if __name__ == '__main__':
    app = QApplication([sys.argv])
    app.setStyle('fusion')
    app.setFont(QFont('JetBrains Mono', 15))
    builder = ERT()
    sys.exit(app.exec_())
